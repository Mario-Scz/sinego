<?php
$pageTitle = 'Logística';
session_start();
if (empty($_SESSION['usuario'])) {
    header('Location: /vistas/register.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logística - Sinego</title>
    <link rel="stylesheet" href="/css/logistica.css">
</head>
<body>
<!-- nav -->
<nav class="n">
  <div class="nc">
    <div class="nl">
      <a href="/vistas/bienvenido.html">
        <img src="/img/sinego.png" alt="Sinego Logo" class="lg" />
      </a>
    </div>
    <input type="checkbox" id="mchk" class="cm" />
    <label for="mchk" class="tm">
      <span></span>
      <span></span>
      <span></span>
    </label>
    <nav class="mn">
      <ul>
        <li><a href="/vistas/bienvenido.php">INICIO</a></li>
        <li><a href="/vistas/imprenta.php">IMPRENTA</a></li>
        <li><a href="/vistas/catalogo.php">CATALOGO</a></li>
        <li><a href="/vistas/register.php">INICIAR SESIÓN</a></li>
        <li><a href="/vistas/menu.php">MENÚ</a></li>
      </ul>
    </nav>
    <div class="ni">
      <a href="/vistas/cart.php" class="ic" title="Carrito">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <circle cx="9" cy="21" r="1"></circle>
          <circle cx="20" cy="21" r="1"></circle>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
        </svg>
        <span class="cc" id="cc">0</span>
      </a>
      <a href="/vistas/favorites.php" class="ic" title="Favoritos">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
        </svg>
        <span class="cf" id="cf">0</span>
      </a>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="h">
  <div class="hc">
    <h1 class="ht">Logística</h1>
    <p class="hs">Gestiona tus envíos y distribuciones</p>
  </div>
</section>

<!-- Main Content -->
<main class="c">
  <section class="ts">
    <div class="te">
      <h2>Envíos y Entregas</h2>
      <a href="log add.php"><button class="b bp">+ Nuevo Envío</button></a>
    </div>
    
    <div class="bb">
      <input type="text" placeholder="Buscar envío por autor o ID de libro..." class="ib" />
    </div>

    <div class="tw">
      <table class="td">
        <thead>
          <tr>
            <th>Autor</th>
            <th>Tipo de Envío</th>
            <th>ID Libro</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td data-label="Autor"><input type="text" value="Juan Manuel" /></td>
            <td data-label="Tipo de Envío"><input type="text" value="Express" /></td>
            <td data-label="ID Libro"><input type="text" value="LIB-2026-001" /></td>
            <td data-label="Acciones">
              <div class="ba">
                <button class="ba e" title="ediar">✏️</button>
                <button class="ba d" title="Eliminar">🗑️</button>
              </div>
            </td>
          </tr>
          <tr>
            <td data-label="Autor"><input type="text" value="María Sánchez" /></td>
            <td data-label="Tipo de Envío"><input type="text" value="Standard" /></td>
            <td data-label="ID Libro"><input type="text" value="LIB-2026-002" /></td>
            <td data-label="Acciones">
              <div class="ba">
                <button class="ba e" title="ediar">✏️</button>
                <button class="ba d" title="Eliminar">🗑️</button>
              </div>
            </td>
          </tr>
          <tr>
            <td data-label="Autor"><input type="text" value="Carlos Fernández" /></td>
            <td data-label="Tipo de Envío"><input type="text" value="Express" /></td>
            <td data-label="ID Libro"><input type="text" value="LIB-2026-003" /></td>
            <td data-label="Acciones">
              <div class="ba">
                <button class="ba e" title="ediar">✏️</button>
                <button class="ba d" title="Eliminar">🗑️</button>
              </div>
            </td>
          </tr>
          <tr>
            <td data-label="Autor"><input type="text" value="Ana García" /></td>
            <td data-label="Tipo de Envío"><input type="text" value="Pickup" /></td>
            <td data-label="ID Libro"><input type="text" value="LIB-2026-004" /></td>
            <td data-label="Acciones">
              <div class="ba">
                <button class="ba e" title="ediar">✏️</button>
                <button class="ba d" title="Eliminar">🗑️</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>
</main>

<script src="/js/common.js"></script>
<script src="/js/logistica.js"></script>
<script src="/js/cart.js"></script>
<script src="/js/favorites.js"></script>
<!-- ftr -->
<footer class="ft">
  <div class="ftc">
    <p>&copy; 2026 Sinego. Todos los derechos reservados.</p>
    <p>Servicio de logística confiable.</p>
  </div>
</footer>
</body>
</html>



