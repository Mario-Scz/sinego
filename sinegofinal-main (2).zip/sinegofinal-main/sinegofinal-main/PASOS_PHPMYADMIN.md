# Pasos para crear el usuario admin en phpMyAdmin

## 1. Entra a phpMyAdmin
Usa estos datos:
- **Servidor:** sql3.freesqldatabase.com
- **Usuario:** sql3818944
- **Contraseña:** t9YcpBF2Sn
- **Base de datos:** sql3818944

## 2. Ejecuta el SQL

1. En el panel de phpMyAdmin, a la izquierda haz clic en tu base de datos **sql3818944**

2. En el menú superior, haz clic en la pestaña **SQL**

3. En el cuadro de texto, copia y pega este código:

```sql
DELETE FROM usuarios WHERE usuario = 'admin';

INSERT INTO usuarios (usuario, contraseña, role, nombre, email) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Administrador', 'admin@sinego.com');
```

4. Haz clic en **Continuar** o **Execute**

## 3. Verifica

Después de ejecutar,，你应该 ver un mensaje de éxito. 
Puedes verificar que el usuario existe ejecutando:
```sql
SELECT * FROM usuarios WHERE usuario = 'admin';
```

---

## 4. Sube archivos a Render.com

Después de crear el usuario, sube estos 2 archivos a tu proyecto en Render:
1. **`.env`** (contiene la conexión a tu base de datos)
2. **`vistas/register.php`** (el formulario corregido)

## 5. Listo!

Ve a https://sinegofinal.onrender.com/vistas/register.php e inicia sesión con:
- **Usuario:** admin
- **Contraseña:** admin123
