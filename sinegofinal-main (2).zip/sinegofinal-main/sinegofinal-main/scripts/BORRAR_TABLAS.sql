-- ============================================
-- BORRAR TODAS LAS TABLAS DE SINEGO
-- Ejecuta este código en phpMyAdmin
-- ============================================

DROP TABLE IF EXISTS favoritos;
DROP TABLE IF EXISTS carrito;
DROP TABLE IF EXISTS libros;
DROP TABLE IF EXISTS logistica;
DROP TABLE IF EXISTS imprenta;
DROP TABLE IF EXISTS facturas;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS usuarios;
