-- ============================================
-- TABLAS PARA SINEGO
-- Ejecuta este código en phpMyAdmin
-- ============================================

-- ============================================
-- 1. USUARIOS (para login)
-- ============================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    contraseña VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    nombre VARCHAR(100) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    telefono VARCHAR(20) DEFAULT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Usuario admin: admin / admin123
INSERT INTO usuarios (usuario, contraseña, role, nombre, email, telefono) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Administrador', 'admin@sinego.com', '1234567890');

-- ============================================
-- 2. TICKETS (Facturación)
-- Clave: folio
-- ============================================
CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) NOT NULL UNIQUE,
    metodo_pago VARCHAR(50) DEFAULT NULL,
    numero_tarjeta_debito VARCHAR(20) DEFAULT NULL,
    numero_tarjeta_credito VARCHAR(20) DEFAULT NULL,
    fecha_emision DATE DEFAULT NULL,
    hora_emision TIME DEFAULT NULL,
    lugar_emision VARCHAR(100) DEFAULT NULL,
    nombre_empresa VARCHAR(100) DEFAULT NULL,
    razon_social VARCHAR(150) DEFAULT NULL,
    rfc VARCHAR(20) DEFAULT NULL,
    regimen_social VARCHAR(100) DEFAULT NULL,
    direccion TEXT DEFAULT NULL,
    producto VARCHAR(150) DEFAULT NULL,
    cantidad INT DEFAULT 1,
    precio DECIMAL(10,2) DEFAULT 0,
    importe_total DECIMAL(10,2) DEFAULT 0,
    nombre_cliente VARCHAR(100) DEFAULT NULL,
    telefono VARCHAR(20) DEFAULT NULL,
    direccion_cliente TEXT DEFAULT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 3. CLIENTES PRODUCTO
-- Clave: id_clientes
-- ============================================
CREATE TABLE IF NOT EXISTS clientes_producto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_clientes VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(20) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    direccion_linea1 VARCHAR(255) DEFAULT NULL,
    direccion_linea2 VARCHAR(255) DEFAULT NULL,
    ciudad VARCHAR(100) DEFAULT NULL,
    codigo_postal VARCHAR(10) DEFAULT NULL,
    estado VARCHAR(100) DEFAULT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 4. PRODUCTO VENDER
-- Clave: id_producto
-- ============================================
CREATE TABLE IF NOT EXISTS producto_vender (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_producto VARCHAR(50) NOT NULL UNIQUE,
    titulo VARCHAR(150) NOT NULL,
    autor VARCHAR(100) DEFAULT NULL,
    fecha_publicacion DATE DEFAULT NULL,
    isbn VARCHAR(20) DEFAULT NULL,
    precio DECIMAL(10,2) DEFAULT 0,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 5. ENVÍO (Logística)
-- Clave: folio
-- ============================================
CREATE TABLE IF NOT EXISTS envios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    folio VARCHAR(50) NOT NULL UNIQUE,
    tipo_envio VARCHAR(50) DEFAULT NULL,
    tiempo_entrega VARCHAR(50) DEFAULT NULL,
    tiempo_recoleccion VARCHAR(50) DEFAULT NULL,
    codigo_area VARCHAR(20) DEFAULT NULL,
    dimensiones VARCHAR(50) DEFAULT NULL,
    peso_paquete DECIMAL(10,2) DEFAULT 0,
    peso_volumetrico DECIMAL(10,2) DEFAULT 0,
    peso_facturable DECIMAL(10,2) DEFAULT 0,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 6. CLIENTES SERVICIO
-- Clave: id_clientes
-- ============================================
CREATE TABLE IF NOT EXISTS clientes_servicio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_clientes VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    telefono VARCHAR(20) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    direccion_linea1 VARCHAR(255) DEFAULT NULL,
    direccion_linea2 VARCHAR(255) DEFAULT NULL,
    ciudad VARCHAR(100) DEFAULT NULL,
    codigo_postal VARCHAR(10) DEFAULT NULL,
    estado VARCHAR(100) DEFAULT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 7. PRODUCTO IMPRIMIR
-- Clave: id_producto
-- ============================================
CREATE TABLE IF NOT EXISTS producto_imprimir (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_producto VARCHAR(50) NOT NULL UNIQUE,
    titulo VARCHAR(150) NOT NULL,
    autor VARCHAR(100) DEFAULT NULL,
    fecha_publicacion DATE DEFAULT NULL,
    isbn VARCHAR(20) DEFAULT NULL,
    dimensiones VARCHAR(50) DEFAULT NULL,
    numero_paginas INT DEFAULT 0,
    tipo_impresion VARCHAR(50) DEFAULT NULL,
    tipo_papel VARCHAR(50) DEFAULT NULL,
    tipo_portada VARCHAR(50) DEFAULT NULL,
    cotizacion DECIMAL(10,2) DEFAULT 0,
    archivo VARCHAR(255) DEFAULT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 8. REPORTES (Admin)
-- Clave: id_reporte
-- ============================================
CREATE TABLE IF NOT EXISTS reportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_reporte VARCHAR(50) NOT NULL UNIQUE,
    fecha DATE DEFAULT NULL,
    creador VARCHAR(100) DEFAULT NULL,
    titulo VARCHAR(150) DEFAULT NULL,
    cuerpo TEXT DEFAULT NULL,
    firma VARCHAR(100) DEFAULT NULL,
    anexos TEXT DEFAULT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 9. PRODUCTOS (Catálogo tienda)
-- ============================================
CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT DEFAULT NULL,
    precio DECIMAL(10,2) NOT NULL DEFAULT 0,
    imagen VARCHAR(255) DEFAULT NULL,
    genero VARCHAR(50) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- 10. CARRITO
-- ============================================
CREATE TABLE IF NOT EXISTS carrito (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- 11. FAVORITOS
-- ============================================
CREATE TABLE IF NOT EXISTS favoritos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    producto_id INT NOT NULL,
    agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
) ENGINE=InnoDB;
