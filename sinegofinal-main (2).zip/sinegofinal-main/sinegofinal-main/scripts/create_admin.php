<?php
/**
 * Script para crear usuario administrador
 * Ejecutar desde terminal: php scripts/create_admin.php
 */

require_once __DIR__ . '/../config/db.php';

// Contraseña: admin123
$password_hash = password_hash('admin123', PASSWORD_DEFAULT);

echo "Hash de contraseña generado: " . $password_hash . "\n\n";

try {
    // Verificar si el usuario ya existe
    $stmt = $pdo->prepare('SELECT id FROM usuarios WHERE usuario = ?');
    $stmt->execute(['admin']);
    $existing = $stmt->fetch();
    
    if ($existing) {
        // Actualizar contraseña
        $stmt = $pdo->prepare('UPDATE usuarios SET contraseña = ?, role = ? WHERE usuario = ?');
        $stmt->execute([$password_hash, 'admin', 'admin']);
        echo "✓ Usuario 'admin' actualizado correctamente\n";
    } else {
        // Crear nuevo usuario
        $stmt = $pdo->prepare('INSERT INTO usuarios (usuario, contraseña, role, nombre, email) VALUES (?, ?, ?, ?, ?)');
        $stmt->execute(['admin', $password_hash, 'admin', 'Administrador', 'admin@sinego.com']);
        echo "✓ Usuario 'admin' creado correctamente\n";
    }
    
    // Verificar que funciona
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE usuario = ?');
    $stmt->execute(['admin']);
    $user = $stmt->fetch();
    
    echo "\n--- Datos del usuario ---\n";
    echo "ID: " . $user['id'] . "\n";
    echo "Usuario: " . $user['usuario'] . "\n";
    echo "Role: " . $user['role'] . "\n";
    echo "Nombre: " . $user['nombre'] . "\n";
    echo "Email: " . $user['email'] . "\n";
    
    // Verificar contraseña
    if (password_verify('admin123', $user['contraseña'])) {
        echo "\n✓ Contraseña verificada correctamente\n";
    } else {
        echo "\n✗ Error: La contraseña no coincide\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
