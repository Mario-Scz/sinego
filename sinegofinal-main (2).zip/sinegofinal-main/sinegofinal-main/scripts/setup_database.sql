-- ============================================
-- ESQUEMA DE BASE DE DATOS PARA SINEGO
-- Ejecuta este código en phpMyAdmin
-- ============================================

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    contraseña VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'user',
    nombre VARCHAR(100) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT DEFAULT NULL,
    precio DECIMAL(10,2) NOT NULL DEFAULT 0,
    imagen VARCHAR(255) DEFAULT NULL,
    genero VARCHAR(50) DEFAULT NULL,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de carrito
CREATE TABLE IF NOT EXISTS carrito (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    producto_id INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tabla de favoritos
CREATE TABLE IF NOT EXISTS favoritos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    producto_id INT NOT NULL,
    agregado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (usuario_id, producto_id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- CREAR USUARIO ADMINISTRADOR
-- Usuario: admin
-- Contraseña: admin123
-- IMPORTANTE: Eliminar usuario admin anterior si existe
-- ============================================
DELETE FROM usuarios WHERE usuario = 'admin';

INSERT INTO usuarios (usuario, contraseña, role, nombre, email) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'Administrador', 'admin@sinego.com');

-- ============================================
-- CREAR PRODUCTOS DE EJEMPLO
-- ============================================
INSERT INTO productos (nombre, descripcion, precio, imagen, genero) VALUES
('Camiseta Básica', 'Camiseta de algodón básica', 150.00, 'https://via.placeholder.com/300', 'unisex'),
('Pantalón Jeans', 'Jeans clásico', 450.00, 'https://via.placeholder.com/300', 'hombre'),
('Vestido Floral', 'Vestido casual de flores', 380.00, 'https://via.placeholder.com/300', 'mujer'),
('Sudadera con Capucha', 'Sudadera cómoda', 320.00, 'https://via.placeholder.com/300', 'unisex'),
('Zapatillas Deportivas', 'Zapatillas para correr', 650.00, 'https://via.placeholder.com/300', 'unisex');

-- ============================================
-- VERIFICAR QUE EL USUARIO FUE CREADO
-- ============================================
SELECT id, usuario, role, nombre, email FROM usuarios WHERE usuario = 'admin';
